<?php
error_reporting(E_ALL & ~E_DEPRECATED & ~E_WARNING);
ini_set('display_errors', 1);

function format_company_data($company_data) {
    return [
        "基本信息" => [
            "公司名称" => $company_data['name'] ?? "无",
            "统一社会信用代码" => $company_data['creditCode'] ?? "无",
            "注册号" => $company_data['regNumber'] ?? "无",
            "组织机构代码" => $company_data['orgNumber'] ?? "无",
            "成立日期" => $company_data['establishTimeShowStr'] ?? $company_data['estiblishTimeShowStr'] ?? "无",
            "企业类型" => $company_data['companyOrgType'] ?? "无",
            "经营状态" => $company_data['regStatus'] ?? "无",
            "注册资本" => $company_data['correctRegCapital'] ?? $company_data['regCapital'] ?? "无",
            "登记机关" => $company_data['registerInstitute'] ?? "无",
            "企业规模" => $company_data['companyScale'] ?? "无"
        ],
        "法定代表人" => [
            "姓名" => $company_data['legalPersonName'] ?? "无",
            "职位" => $company_data['legalPersonShowStr'] ?? "无"
        ],
        "联系方式" => [
            "电话" => $company_data['phone'] ?? "无",
            "邮箱" => $company_data['emails'] ?? "无",
            "网址" => $company_data['websites'] ?? "无"
        ],
        "经营信息" => [
            "经营范围" => $company_data['businessScope'] ?? "无",
            "所属行业" => $company_data['categoryStr'] ?? "无",
            "详细地址" => $company_data['regLocation'] ?? "无",
            "省份" => $company_data['base'] ?? "无",
            "城市" => $company_data['city'] ?? "无",
            "区县" => $company_data['district'] ?? "无"
        ],
        "风险信息" => [
            "自身风险" => $company_data['selfRiskCount'] ?? 0,
            "关联风险" => $company_data['relatedRiskCount'] ?? 0,
            "历史风险" => $company_data['historyRiskCount'] ?? 0
        ]
    ];
}

function print_formatted_data($formatted_data) {
    echo "\n" . str_repeat("=", 50) . "\n";
    echo "公司名称: " . $formatted_data['基本信息']['公司名称'] . "\n";
    echo "统一社会信用代码: " . $formatted_data['基本信息']['统一社会信用代码'] . "\n";
    echo "成立日期: " . $formatted_data['基本信息']['成立日期'] . "\n";
    echo str_repeat("=", 50) . "\n\n";
    echo "=== 详细信息 ===\n";
    foreach ($formatted_data as $category => $info) {
        echo "\n【" . $category . "】\n";
        foreach ($info as $key => $value) {
            echo $key . ": " . $value . "\n";
        }
    }
    echo "\n" . str_repeat("=", 50) . "\n";
    echo "数据来源: 天眼查\n";
    echo str_repeat("=", 50) . "\n";
}

function decompress_response($response, $encoding) {
    switch ($encoding) {
        case 'gzip':
            return gzdecode($response);
        case 'br':
            return brotli_uncompress($response);
        default:
            return $response;
    }
}

function search_company_by_credit_code($credit_code) {
    $url = "https://capi.tianyancha.com/cloud-tempest/app/searchCompany";
    $headers = [
        "X-AUTH-TOKEN: eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxODkyOTQyNTM4NiIsImlhdCI6MTc1MzYxODgzNSwiZXhwIjoxNzU2MjEwODM1fQ.GXXkSh57yWE_bO_cCoh157lw6ZneEf2WWps5T_UqPvwIhYxOKLw0VYm_rXT4oe6THSyRnL8oPv3Lzb7RT9Zbag",
        "Connection: keep-alive",
        "User-Agent: Mozilla/5.0 (iPad; CPU OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.47(0x18002f2c) NetType/WIFI Language/zh_CN",
        "Accept-Encoding: gzip, br, deflate",
        "Host: capi.tianyancha.com",
        "version: TYC-XCX-WX",
        "Referer: https://servicewechat.com/wx9f2867fc22873452/125/page-frame.html",
        "content-type: application/json",
        "Authorization: 0###oo34J0eKmwZ2dziXSAWUtKRQi6Kk###1753618144609###4cce55c68fd91cbcc10191da0798b93c"
    ];
    $payload = json_encode([
        "sortType" => 0,
        "pageSize" => 20,
        "pageNum" => 1,
        "word" => $credit_code,
        "allowModifyQuery" => 1
    ]);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_HEADER, true);

    $response = curl_exec($ch);
    $error = curl_error($ch);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);

    if ($error) {
        echo "请求出错: " . $error;
        return;
    }

    $header = substr($response, 0, $header_size);
    $body = substr($response, $header_size);

    $encoding = '';
    if (preg_match('/Content-Encoding: (\w+)/i', $header, $matches)) {
        $encoding = strtolower($matches[1]);
    }
    $body = decompress_response($body, $encoding);

    $data = json_decode($body, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo "JSON解析出错: " . json_last_error_msg() . "\n";
        echo "原始响应内容: " . $body;
        return;
    }

    if ($data['state'] === "ok" && !empty($data['data']['companyList'][0])) {
        $company = $data['data']['companyList'][0];
        $formatted_data = format_company_data($company);
        print_formatted_data($formatted_data);
    } else {
        echo "未找到匹配的公司信息";
    }
}

if (isset($_GET['credit_code'])) {
    $credit_code = trim($_GET['credit_code']);
    if (!empty($credit_code)) {
        search_company_by_credit_code($credit_code);
    } else {
        echo "请输入有效的统一信用代码";
    }
} else {
    echo "参数错误！请使用 tycfr.php?credit_code=法人信用代码";
}
?>